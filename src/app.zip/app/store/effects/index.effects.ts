import { EmployeeEffects } from './employee.effects';

export const effects = [EmployeeEffects];
