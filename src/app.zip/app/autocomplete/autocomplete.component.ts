import { Component, forwardRef, OnInit, Input } from '@angular/core';
import { Store, select } from '@ngrx/store';
import * as EmpsActions from '../store/actions/employee.actions';
import * as fromRoot from '../store/reducers/index.reducer';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'app-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AutocompleteComponent),
      multi: true
    }
  ]
})
export class AutocompleteComponent implements OnInit, ControlValueAccessor {
  @Input('value') val: string;
  public search: string;
  public searchData: Array<any> = [];
  public isDisplay;

  constructor(private store: Store<fromRoot.State>) {
    store.pipe(select(fromRoot.getAllEmps)).subscribe(res => {
      this.searchData = res;
    });
  }
  onChange: any = () => { };
  onTouched: any = () => { };
  get value() {
    return this.val;
  }
  set value(val) {
    this.val = val;
    this.onChange(val);
    this.onTouched();
  }
  registerOnChange(fn) {
    this.onChange = fn;
  }

  registerOnTouched(fn) {
    this.onTouched = fn;
  }
  writeValue(value) {
    if (value) {
      this.value = value;
    }
  }
  ngOnInit() {
    this.isDisplay = false;
  }

  select(item) {
    this.search = item.company;
    this.isDisplay = false;
    this.value = this.search;
  }
  filter() {
    this.isDisplay = true;
    this.value = this.search;
    if (this.search.length > 2) {
      this.store.dispatch(new EmpsActions.SearchEmpRequest({ company_like: this.search }));
    } else {
      if (!this.search) {
        this.searchData = [];
      }
    }
  }
}
